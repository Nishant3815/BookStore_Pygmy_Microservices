#!/bin/bash

cd BookStore_Pygmy_Microservices
sudo docker-compose build -q
sudo docker-compose up -d
